# Soapy Vortex Analyzer

A Python script for IYPT problem #10 (*Dancing Soapy Vortices*) that
takes a video of a sound-driven soap film and returns:

* the **driving frequency** (extracted automatically from the video's
  audio track via FFT)
* the **mean velocity** of the colourful vortices moving across the
  film (in mm/s if you give a physical scale, otherwise in px/s)
* per-frame **vorticity** maps and quiver plots
* a **CSV** with per-frame speeds you can drop into your IYPT plots

## How it works

1. **Audio FFT** – decodes the audio track and finds the dominant peak
   in 50 – 3000 Hz. That is the sound the speaker was actually
   producing during the recording.
2. **ROI detection** – the soap film stands out because its
   interference fringes show *many hues at once*. The script computes a
   local "hue-variety" score (1 − resultant length of hue vectors),
   multiplies it by saturation×value, finds the most circular blob and
   fits a circle to it. This deliberately ignores the yellow masking
   tape and the matt PVC, which are highly saturated but mono-chromatic.
3. **Dense optical flow** (Farneback) is run on every consecutive pair
   of frames inside the ROI. The flow vectors tell you, in pixels per
   frame, where each coloured patch moved between frames.
4. **Physical units**: if you pass `--film-diameter-mm 25`, the script
   uses the detected ROI diameter (px) and that physical diameter to
   convert px/frame → mm/s via the video's FPS.
5. The curl of the flow field gives **vorticity** – this is what makes
   the swirling vortices show up as red/blue lobes in the heatmap.

## Usage

```bash
pip install opencv-python numpy matplotlib scipy
# ffmpeg must be installed and on PATH

python soapy_vortex_analyzer.py \
    --video 345hz.mp4 \
    --film-diameter-mm 25 \
    --output-dir out_345
```

Useful flags:

| flag | meaning |
|---|---|
| `--film-diameter-mm 25` | physical aperture diameter; needed for mm/s output |
| `--frequency-hz 345`    | override audio-detected frequency (if audio is poor) |
| `--roi 230,440,80,80`   | manual ROI as `x,y,w,h` if auto-detect fails |
| `--start-time 2`        | skip the first 2 seconds (handling, focusing) |
| `--end-time 30`         | only analyse up to t = 30 s |

## Outputs (in `--output-dir`)

| file | what it is |
|---|---|
| `summary.json`                | mean & 95th-percentile speed, frequency, ROI, scale |
| `velocity_data.csv`           | per-frame speed + vorticity, ready for plotting |
| `roi_detected.png`            | the full frame with the detected ROI box drawn on it – **always check this first** |
| `audio_spectrum.png`          | the audio FFT with the detected peak marked |
| `flow_field_sample.png`       | one frame with optical-flow vectors overlaid |
| `vorticity_sample.png`        | the curl-of-velocity heatmap (vortex cores) |
| `velocity_time_series.png`    | mean & 95-th-percentile speed vs time and peak vorticity vs time |

## Mapping velocity ↔ frequency across many videos

For your IYPT investigation, record several videos at different
frequencies (e.g. 320, 345, 400, 450, 500, 600 Hz) and run the script
on each one with a unique `--output-dir`. Then:

```python
import json, glob, matplotlib.pyplot as plt
points = []
for f in glob.glob("out_*/summary.json"):
    s = json.load(open(f))
    points.append((s["driving_frequency_hz"], s["mean_speed"]))
points.sort()
freq, vel = zip(*points)
plt.scatter(freq, vel); plt.xlabel("driving frequency (Hz)")
plt.ylabel("mean vortex speed (mm/s)"); plt.savefig("v_vs_f.png")
```

That gives you the velocity-vs-frequency curve and lets you identify
the resonance peak (max velocity ↔ optimal sound frequency for vortex
formation).

## Caveats & physics notes

* **Optical-flow caveat.** What we are measuring is the motion of the
  *colour pattern* on the film. The colour at each point depends on
  film thickness, so what moves is not the soap molecules directly but
  the thickness fronts – effectively the surface-flow velocity in the
  plane of the film. For most soap-film studies this is exactly the
  quantity of interest.
* **Sub-frame motion** can alias if the vortices spin faster than the
  camera can resolve. Your phone shoots at 24 fps here, so any motion
  faster than ~12 cycles/s in the pattern will alias. For higher driving
  frequencies you'll want a higher-fps recording (240 fps "slo-mo" mode
  on most phones works well).
* The vortices in the colour pattern don't move at the acoustic
  frequency – the sound drives the membrane resonance, and the
  resulting flow is *much* slower (mm/s, not Hz × mm). The relationship
  is the interesting bit of the investigation.
* **Audio detection may pick up overtones.** If the bottle has a strong
  acoustic resonance, the FFT might find that instead of the speaker's
  fundamental. Always cross-check `audio_spectrum.png` against what you
  set on the tone generator and use `--frequency-hz` if needed.
* **Scale calibration.** The script assumes the visible iridescent disc
  fills the aperture you specify with `--film-diameter-mm`. If only
  part of the aperture has film, measure that visible disc instead and
  pass its diameter.
