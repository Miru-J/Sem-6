#!/usr/bin/env python3
"""
soapy_vortex_analyzer.py
========================
Analyse a video of a soap film driven by sound (IYPT problem #10:
"Dancing Soapy Vortices") to estimate the velocity of the vortex
patterns moving across the film, and pair that velocity with the
acoustic driving frequency extracted automatically from the audio.

Pipeline
--------
1. Read FPS and number of frames from the video.
2. Decode the audio track, run an FFT, report the dominant frequency.
3. Auto-detect the soap-film region of interest (ROI) by looking for
   the highly-saturated iridescent patch in HSV space (you can also
   pass --roi x,y,w,h to override).
4. For every consecutive pair of frames inside the ROI:
       - compute dense Farneback optical flow (px/frame)
       - mask out background pixels (low saturation)
       - record the mean speed and the 95th-percentile speed
       - compute the curl (vorticity) field
5. Convert px/frame -> px/s using FPS, and px/s -> mm/s if a physical
   scale is supplied (--film-diameter-mm together with the detected
   ROI diameter in pixels gives mm per pixel).
6. Save plots, an annotated frame, a CSV with per-frame data, and a
   summary JSON.

Usage
-----
    python soapy_vortex_analyzer.py --video 345hz.mp4 \
                                    --film-diameter-mm 25 \
                                    --output-dir out_345

Dependencies: opencv-python, numpy, matplotlib, scipy, imageio[ffmpeg].
"""

import argparse, json, os, subprocess, sys, tempfile
from pathlib import Path
import numpy as np
import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.io import wavfile
from scipy.signal import find_peaks


# ----------------------------------------------------------------------
# 1. AUDIO  --  pull the driving frequency straight from the soundtrack
# ----------------------------------------------------------------------
def dominant_audio_frequency(video_path, fmin=50, fmax=3000):
    """Extract audio with ffmpeg, run an FFT, return the dominant tone
    (Hz) inside [fmin, fmax]. Returns None if no audio track exists."""
    with tempfile.TemporaryDirectory() as tmp:
        wav = Path(tmp) / "audio.wav"
        r = subprocess.run(
            ["ffmpeg", "-y", "-i", str(video_path),
             "-vn", "-ac", "1", "-ar", "44100", "-f", "wav", str(wav)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if r.returncode != 0 or not wav.exists():
            return None, None, None
        sr, data = wavfile.read(wav)
    if data.ndim > 1:
        data = data.mean(axis=1)
    data = data.astype(np.float64)
    data -= data.mean()
    # Welch-style: average FFT magnitudes over windows for a cleaner spectrum
    win = 1 << 15                                          # 32 768 samples
    if len(data) < win:
        win = len(data)
    hop = win // 2
    mags = []
    for s in range(0, len(data) - win + 1, hop):
        seg = data[s:s + win] * np.hanning(win)
        mags.append(np.abs(np.fft.rfft(seg)))
    mag = np.mean(mags, axis=0) if mags else np.abs(np.fft.rfft(data))
    freqs = np.fft.rfftfreq(win, 1 / sr)
    band = (freqs >= fmin) & (freqs <= fmax)
    f_band, m_band = freqs[band], mag[band]
    f_peak = float(f_band[np.argmax(m_band)])
    return f_peak, f_band, m_band


# ----------------------------------------------------------------------
# 2. ROI  --  find the iridescent soap film in the frame
# ----------------------------------------------------------------------
def _local_hue_variety(hsv, win=11):
    """For each pixel, return the spread of hues in a small window.
    Soap-film interference shows many hues simultaneously, so this is
    high on the film and low on uniform-colour regions (tape, paper)."""
    H = hsv[..., 0].astype(np.float32)
    # treat hue as an angle, average the sin & cos components
    sin = np.sin(H * np.pi / 90.0)        # H is 0..179 in OpenCV
    cos = np.cos(H * np.pi / 90.0)
    k = (win, win)
    sin_m = cv2.boxFilter(sin, ddepth=-1, ksize=k)
    cos_m = cv2.boxFilter(cos, ddepth=-1, ksize=k)
    # 1 - resultant length  →  0 for uniform hue, ~1 for very mixed hues
    R = np.sqrt(sin_m * sin_m + cos_m * cos_m)
    return 1.0 - R


def detect_film_roi(frame_bgr, pad=10, min_d=20, max_d=200):
    """Find the soap film: a compact, circular region whose pixels have
    high saturation AND high local hue variety (multi-coloured fringes).
    Falls back to HoughCircles if blob analysis is ambiguous."""
    hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
    S = hsv[..., 1].astype(np.float32) / 255.0
    V = hsv[..., 2].astype(np.float32) / 255.0
    hue_var = _local_hue_variety(hsv, win=11)
    # combine: needs to be saturated, bright-ish AND multi-hued
    score = S * V * hue_var
    score = cv2.GaussianBlur(score, (9, 9), 0)
    thr = max(score.mean() + 2 * score.std(),
              np.percentile(score, 99.0) * 0.55)
    mask = (score > thr).astype(np.uint8) * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,
                            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE,
                            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))

    H_img, W_img = frame_bgr.shape[:2]
    best, best_score = None, -1.0
    n, lbl, stats, cents = cv2.connectedComponentsWithStats(mask, 8)
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if area < 40:                              continue
        if max(w, h) > max_d * 2 or min(w, h) < 4: continue
        # compactness: how close to a filled circle is this blob?
        circ_area = np.pi * (max(w, h) / 2) ** 2
        compactness = area / circ_area             # 1.0 = perfect circle
        aspect = min(w, h) / max(w, h)             # 1.0 = square bbox
        mean_score = float(score[lbl == i].mean())
        s = mean_score * compactness * aspect
        if s > best_score:
            best_score, best = s, (x, y, w, h, i)

    if best is None:
        # fallback: HoughCircles on the saturation channel
        gray = (S * 255).astype(np.uint8)
        gray = cv2.medianBlur(gray, 5)
        circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, dp=1.2,
                                   minDist=30, param1=80, param2=18,
                                   minRadius=min_d // 2,
                                   maxRadius=max_d // 2)
        if circles is None:
            return W_img // 4, H_img // 4, W_img // 2, H_img // 2, \
                   np.ones((H_img, W_img), np.uint8) * 255
        cx, cy, r = np.round(circles[0, 0]).astype(int)
        x, y, w, h = max(0, cx - r), max(0, cy - r), 2 * r, 2 * r
        blob = np.zeros((H_img, W_img), np.uint8)
        cv2.circle(blob, (cx, cy), r, 255, -1)
        return int(x), int(y), int(w), int(h), blob

    x, y, w, h, idx = best
    # tighten by fitting a circle to the blob's contour
    contours, _ = cv2.findContours((lbl == idx).astype(np.uint8) * 255,
                                   cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    blob = np.zeros((H_img, W_img), np.uint8)
    if contours:
        (cx, cy), r = cv2.minEnclosingCircle(max(contours, key=cv2.contourArea))
        cx, cy, r = int(cx), int(cy), int(r)
        # use the fitted circle for the mask (cleaner than the raw blob)
        cv2.circle(blob, (cx, cy), max(1, r - 1), 255, -1)
        x, y = max(0, cx - r), max(0, cy - r)
        w, h = 2 * r, 2 * r
    else:
        blob = (lbl == idx).astype(np.uint8) * 255

    x = max(0, x - pad); y = max(0, y - pad)
    w = min(W_img - x, w + 2 * pad); h = min(H_img - y, h + 2 * pad)
    return int(x), int(y), int(w), int(h), blob


# ----------------------------------------------------------------------
# 3. Optical flow  --  vortex motion frame-to-frame
# ----------------------------------------------------------------------
def analyse_flow(video_path, roi, full_film_mask, start_frame, end_frame,
                 sat_threshold=30):
    """Run dense Farneback optical flow on the ROI. Returns per-frame
    arrays of (time_s, mean_speed_px_per_frame, p95_speed, peak_vorticity)
    plus the last flow/frame for visualisation."""
    cap = cv2.VideoCapture(str(video_path))
    fps = cap.get(cv2.CAP_PROP_FPS)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    end_frame = min(end_frame, total - 1)
    x, y, w, h = roi
    film_mask_roi = full_film_mask[y:y + h, x:x + w]

    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    ok, prev = cap.read()
    if not ok:
        cap.release(); raise RuntimeError("could not read start frame")
    prev_gray = cv2.cvtColor(prev[y:y + h, x:x + w], cv2.COLOR_BGR2GRAY)

    times, mean_v, p95_v, peak_w = [], [], [], []
    last_flow, last_frame_roi, last_mask = None, None, None

    for fidx in range(start_frame + 1, end_frame + 1):
        ok, cur = cap.read()
        if not ok:
            break
        cur_roi = cur[y:y + h, x:x + w]
        cur_gray = cv2.cvtColor(cur_roi, cv2.COLOR_BGR2GRAY)
        flow = cv2.calcOpticalFlowFarneback(
            prev_gray, cur_gray, None,
            pyr_scale=0.5, levels=3, winsize=15,
            iterations=3, poly_n=5, poly_sigma=1.2, flags=0)
        fx, fy = flow[..., 0], flow[..., 1]
        speed = np.sqrt(fx * fx + fy * fy)
        # per-frame mask: must be inside the film AND currently coloured
        hsv = cv2.cvtColor(cur_roi, cv2.COLOR_BGR2HSV)
        mask = (hsv[..., 1] > sat_threshold) & (film_mask_roi > 0)
        if mask.sum() < 30:
            prev_gray = cur_gray; continue
        sp = speed[mask]
        # vorticity = d(fy)/dx - d(fx)/dy
        dfy_dx = np.gradient(fy, axis=1)
        dfx_dy = np.gradient(fx, axis=0)
        vort = dfy_dx - dfx_dy
        peak_w.append(float(np.max(np.abs(vort[mask]))))
        mean_v.append(float(sp.mean()))
        p95_v.append(float(np.percentile(sp, 95)))
        times.append(fidx / fps)
        last_flow, last_frame_roi, last_mask = flow, cur_roi.copy(), mask
        prev_gray = cur_gray

    cap.release()
    return (np.array(times), np.array(mean_v), np.array(p95_v),
            np.array(peak_w), fps, last_flow, last_frame_roi, last_mask)


# ----------------------------------------------------------------------
# 4. Visualisation
# ----------------------------------------------------------------------
def save_flow_overlay(frame_roi, flow, mask, out_path, step=8):
    h, w = frame_roi.shape[:2]
    fig, ax = plt.subplots(figsize=(5, 5 * h / w))
    ax.imshow(cv2.cvtColor(frame_roi, cv2.COLOR_BGR2RGB))
    ys, xs = np.mgrid[step // 2:h:step, step // 2:w:step]
    u = flow[ys, xs, 0]; v = flow[ys, xs, 1]
    m = mask[ys, xs]
    ax.quiver(xs[m], ys[m], u[m], -v[m], color="white",
              scale=None, scale_units="xy", width=0.004)
    ax.set_title("Optical-flow field on soap film")
    ax.axis("off")
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)


def save_vorticity(frame_roi, flow, mask, out_path):
    fy = flow[..., 1]; fx = flow[..., 0]
    vort = np.gradient(fy, axis=1) - np.gradient(fx, axis=0)
    vshow = np.where(mask, vort, np.nan)
    fig, axes = plt.subplots(1, 2, figsize=(9, 4.5))
    axes[0].imshow(cv2.cvtColor(frame_roi, cv2.COLOR_BGR2RGB))
    axes[0].set_title("Film frame"); axes[0].axis("off")
    im = axes[1].imshow(vshow, cmap="RdBu_r",
                        vmin=-np.nanpercentile(np.abs(vshow), 98),
                        vmax=np.nanpercentile(np.abs(vshow), 98))
    axes[1].set_title("Vorticity (curl of flow)"); axes[1].axis("off")
    fig.colorbar(im, ax=axes[1], fraction=0.046)
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)


def save_time_series(t, mean_v, p95_v, peak_w, scale_mm_per_px, fps,
                     out_path):
    fig, axes = plt.subplots(2, 1, figsize=(8, 6), sharex=True)
    mean_phys = mean_v * fps * scale_mm_per_px
    p95_phys  = p95_v  * fps * scale_mm_per_px
    axes[0].plot(t, mean_phys, label="mean speed")
    axes[0].plot(t, p95_phys,  label="95th-percentile speed", alpha=.7)
    axes[0].axhline(mean_phys.mean(), color="k", ls="--",
                    label=f"⟨mean⟩ = {mean_phys.mean():.2f} mm/s")
    axes[0].set_ylabel("speed  (mm/s)"); axes[0].legend(); axes[0].grid(alpha=.3)
    axes[1].plot(t, peak_w, color="purple")
    axes[1].set_ylabel("peak |vorticity| (1/frame)")
    axes[1].set_xlabel("time (s)"); axes[1].grid(alpha=.3)
    fig.suptitle("Vortex motion on soap film")
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)


def save_spectrum(f_band, m_band, f_peak, out_path):
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.semilogy(f_band, m_band)
    ax.axvline(f_peak, color="r", ls="--",
               label=f"dominant: {f_peak:.1f} Hz")
    ax.set_xlabel("frequency (Hz)"); ax.set_ylabel("|FFT|")
    ax.set_title("Audio spectrum (driving sound)")
    ax.legend(); ax.grid(alpha=.3, which="both")
    fig.tight_layout(); fig.savefig(out_path, dpi=140); plt.close(fig)


# ----------------------------------------------------------------------
# 5. Main
# ----------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--video", required=True)
    ap.add_argument("--output-dir", default="vortex_out")
    ap.add_argument("--film-diameter-mm", type=float, default=None,
                    help="actual diameter of the soap-film aperture in mm; "
                         "enables conversion of px-based velocities into mm/s")
    ap.add_argument("--frequency-hz", type=float, default=None,
                    help="override audio-detected driving frequency")
    ap.add_argument("--roi", type=str, default=None,
                    help="manual ROI as x,y,w,h (skip auto-detect)")
    ap.add_argument("--start-time", type=float, default=2.0,
                    help="seconds to skip at the beginning (default 2)")
    ap.add_argument("--end-time", type=float, default=None,
                    help="last second to analyse (default = end of video)")
    args = ap.parse_args()

    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)

    # ---- audio frequency ----
    print("• extracting audio spectrum…")
    f_peak, f_band, m_band = dominant_audio_frequency(args.video)
    if args.frequency_hz is not None:
        f_peak = args.frequency_hz
    if f_band is not None:
        save_spectrum(f_band, m_band, f_peak, out / "audio_spectrum.png")
    print(f"  driving frequency = {f_peak:.2f} Hz" if f_peak else
          "  (no audio detected)")

    # ---- ROI ----
    cap = cv2.VideoCapture(args.video)
    fps = cap.get(cv2.CAP_PROP_FPS)
    nframes = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    start_f = int(args.start_time * fps)
    end_f   = nframes - 2 if args.end_time is None else int(args.end_time * fps)
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_f)
    ok, frame0 = cap.read(); cap.release()
    if not ok:
        sys.exit("could not read start frame")

    if args.roi:
        x, y, w, h = [int(v) for v in args.roi.split(",")]
        film_mask = np.zeros(frame0.shape[:2], np.uint8)
        film_mask[y:y + h, x:x + w] = 255
    else:
        x, y, w, h, film_mask = detect_film_roi(frame0)
    print(f"• ROI = ({x},{y},{w},{h})   FPS = {fps:.2f}   "
          f"frames {start_f}-{end_f}")

    # save a frame with ROI marked
    dbg = frame0.copy()
    cv2.rectangle(dbg, (x, y), (x + w, y + h), (0, 255, 0), 2)
    cv2.imwrite(str(out / "roi_detected.png"), dbg)

    # ---- physical scale ----
    if args.film_diameter_mm:
        # use the smaller side of the ROI as the apparent diameter
        diam_px = min(w, h)
        mm_per_px = args.film_diameter_mm / diam_px
        print(f"• scale: {diam_px}px ↔ {args.film_diameter_mm} mm  "
              f"→ {mm_per_px:.4f} mm/px")
    else:
        mm_per_px = 1.0      # outputs will be in px instead of mm
        print("• no --film-diameter-mm given; velocities reported in px/s")

    # ---- optical flow ----
    print("• running dense optical flow on the film…")
    (t, mean_v, p95_v, peak_w, fps, flow, frame_roi, mask) = analyse_flow(
        args.video, (x, y, w, h), film_mask, start_f, end_f)
    if len(t) == 0:
        sys.exit("no usable frames found in ROI")

    mean_speed_px_per_s = float(mean_v.mean() * fps)
    p95_speed_px_per_s  = float(p95_v.mean()  * fps)
    mean_speed_phys = mean_speed_px_per_s * mm_per_px
    p95_speed_phys  = p95_speed_px_per_s  * mm_per_px

    # ---- save artefacts ----
    save_flow_overlay(frame_roi, flow, mask, out / "flow_field_sample.png")
    save_vorticity   (frame_roi, flow, mask, out / "vorticity_sample.png")
    save_time_series (t, mean_v, p95_v, peak_w, mm_per_px, fps,
                      out / "velocity_time_series.png")

    # ---- per-frame CSV ----
    import csv
    with open(out / "velocity_data.csv", "w", newline="") as fh:
        wr = csv.writer(fh)
        wr.writerow(["time_s", "mean_speed_px_per_frame",
                     "p95_speed_px_per_frame",
                     "mean_speed_phys", "p95_speed_phys", "peak_vorticity"])
        for i in range(len(t)):
            wr.writerow([f"{t[i]:.4f}", f"{mean_v[i]:.4f}",
                         f"{p95_v[i]:.4f}",
                         f"{mean_v[i] * fps * mm_per_px:.4f}",
                         f"{p95_v[i] * fps * mm_per_px:.4f}",
                         f"{peak_w[i]:.4f}"])

    summary = {
        "video": str(args.video),
        "fps": fps,
        "frames_analysed": int(len(t)),
        "driving_frequency_hz": f_peak,
        "roi_xywh": [x, y, w, h],
        "mm_per_px": mm_per_px,
        "units": "mm/s" if args.film_diameter_mm else "px/s",
        "mean_speed": mean_speed_phys,
        "mean_speed_std": float(np.std(mean_v * fps * mm_per_px)),
        "p95_speed":  p95_speed_phys,
        "mean_speed_px_per_s": mean_speed_px_per_s,
        "p95_speed_px_per_s":  p95_speed_px_per_s,
        "mean_peak_vorticity_per_frame": float(peak_w.mean()),
    }
    with open(out / "summary.json", "w") as fh:
        json.dump(summary, fh, indent=2)

    print("\n========= SUMMARY =========")
    print(f"  driving frequency   : {f_peak:.2f} Hz" if f_peak
          else "  driving frequency   : n/a")
    unit = "mm/s" if args.film_diameter_mm else "px/s"
    print(f"  mean vortex speed   : {mean_speed_phys:.3f} {unit}")
    print(f"  95th-percentile     : {p95_speed_phys:.3f} {unit}")
    print(f"  results written to  : {out.resolve()}")


if __name__ == "__main__":
    main()
