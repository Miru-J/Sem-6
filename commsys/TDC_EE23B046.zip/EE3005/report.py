
import numpy as np
import scipy.signal as sp

# MINIMUM VARIANCE clearly identifies off=0 as correct.
# Now build the final corrected receiver and verify full BER curve.

FS = 44100;
FC = 5500;
SPS = 4;
ROLL = 0.35;
RRC_TAPS = 81;
LPF_TAPS = 81;
ZC_LEN = 127;
N_BITS = 100000


def make_rrc():
    beta, sps, ntaps = ROLL, SPS, RRC_TAPS
    t = np.arange(-ntaps // 2, ntaps // 2 + 1) / sps;
    h = np.zeros_like(t)
    for i, ti in enumerate(t):
        if abs(ti) < 1e-12:
            h[i] = 1 - beta + 4 * beta / np.pi
        elif abs(abs(ti) - 1 / (4 * beta)) < 1e-12:
            h[i] = (beta / np.sqrt(2)) * (
                        (1 + 2 / np.pi) * np.sin(np.pi / (4 * beta)) + (1 - 2 / np.pi) * np.cos(np.pi / (4 * beta)))
        else:
            h[i] = (np.sin(np.pi * ti * (1 - beta)) + 4 * beta * ti * np.cos(np.pi * ti * (1 + beta))) / (
                        np.pi * ti * (1 - (4 * beta * ti) ** 2))
    h /= np.sqrt(np.sum(h ** 2));
    return h


RRC = make_rrc();
LPF = sp.firwin(LPF_TAPS, min(1.2 * (FS / SPS) / (FS / 2), 0.99))
REFS = np.exp(1j * np.array([1, 3, 5, 7]) * np.pi / 4)
_ENC = {(0, 0): 0, (0, 1): 1, (1, 1): 2, (1, 0): 3};
_DEC = {0: (0, 0), 1: (0, 1), 2: (1, 1), 3: (1, 0)}
RRC_DELAY = len(RRC) // 2;
LPF_DELAY = LPF_TAPS // 2
TOTAL_RX_DELAY = LPF_DELAY + 2 * RRC_DELAY  # 122: LPF(40)+RRC_TX(41)+RRC_RX(41)


def diff_encode(bits):
    if len(bits) % 2: bits = np.append(bits, 0)
    pairs = bits.reshape(-1, 2);
    idx = np.zeros(len(pairs) + 1, dtype=int)
    for i, p in enumerate(pairs): idx[i + 1] = (idx[i] + _ENC[tuple(p)]) % 4
    return REFS[idx]


def diff_decode(syms):
    idx = np.argmin(np.abs(syms[:, None] - REFS[None, :]), axis=1);
    bits = []
    for i in range(1, len(idx)): step = int((idx[i] - idx[i - 1]) % 4); bits.extend(_DEC[step])
    return np.array(bits, dtype=int)


def make_zc_passband():
    n = np.arange(ZC_LEN);
    zc = np.real(np.exp(-1j * np.pi * n * (n + 1) / ZC_LEN))
    zc /= np.max(np.abs(zc));
    up = np.zeros(ZC_LEN * SPS);
    up[::SPS] = zc
    bb = np.convolve(up, RRC);
    t = np.arange(len(bb)) / FS
    pb = bb * np.cos(2 * np.pi * FC * t);
    return pb / np.max(np.abs(pb))


ZC_PASSBAND = make_zc_passband();
ZC_LEN_SAMP = len(ZC_PASSBAND)


def transmitter(bits):
    syms = diff_encode(bits)
    up = np.zeros(len(syms) * SPS, dtype=complex);
    up[::SPS] = syms
    I_bb = np.convolve(np.real(up), RRC);
    Q_bb = np.convolve(np.imag(up), RRC)
    t_d = np.arange(len(I_bb)) / FS
    tx = I_bb * np.cos(2 * np.pi * FC * t_d) - Q_bb * np.sin(2 * np.pi * FC * t_d)
    guard = np.zeros(int(0.02 * FS))
    frame = np.concatenate([guard, ZC_PASSBAND, tx, guard])
    return (frame / np.max(np.abs(frame))).astype(float)


def receiver(rx, nbits):
    t_full = np.arange(len(rx)) / FS
    I_full = 2 * rx * np.cos(2 * np.pi * FC * t_full)
    Q_full = -2 * rx * np.sin(2 * np.pi * FC * t_full)
    I_full = sp.lfilter(LPF, 1, I_full);
    Q_full = sp.lfilter(LPF, 1, Q_full)
    I_mf = np.convolve(I_full, RRC);
    Q_mf = np.convolve(Q_full, RRC)
    iq_full = I_mf + 1j * Q_mf

    corr_abs = np.abs(np.correlate(rx, ZC_PASSBAND, mode='valid'))
    peak = int(np.argmax(corr_abs))
    data_start_iq = peak + ZC_LEN_SAMP + TOTAL_RX_DELAY
    iq_data = iq_full[data_start_iq:]

    # Timing: MINIMUM VARIANCE of |z| picks correct symbol instant
    best_off, best_var = 0, np.inf
    for off in range(SPS):
        seg = iq_data[off::SPS][:500]
        if len(seg) < 50: continue
        v = np.var(np.abs(seg))
        if v < best_var: best_var, best_off = v, off

    n_syms = nbits // 2 + 1  # NO SKIP needed - delay is exact
    syms = iq_data[best_off::SPS][:n_syms]
    return diff_decode(syms)[:nbits]


def awgn(x, snr_db):
    p = np.mean(x ** 2);
    return x + np.sqrt(p / 10 ** (snr_db / 10)) * np.random.randn(len(x))


# Zero noise test
np.random.seed(42)
bits = np.random.randint(0, 2, 1000)
tx = transmitter(bits);
rx = tx.copy()
rb = receiver(rx, len(bits))
print(
    f"Zero noise BER: {np.mean(bits != rb[:len(bits)]):.6f}  ({'PASS' if np.mean(bits != rb[:len(bits)]) == 0 else 'FAIL'})")

# Full BER curve
print(f"\n{'SNR':>6}  {'BER':>12}  Status")
print("-" * 35)
for snr in [0, 2, 4, 6, 8, 10, 12, 15, 20, 25, 30]:
    np.random.seed(snr)
    bits = np.random.randint(0, 2, N_BITS)
    tx = transmitter(bits);
    rx = awgn(tx, snr)
    rb = receiver(rx, N_BITS)
    L = min(len(bits), len(rb))
    ber = float(np.mean(bits[:L] != rb[:L]))
    s = "✓<1e-5" if ber < 1e-5 else "✓<1e-3" if ber < 1e-3 else "✓<1e-2" if ber < 1e-2 else "✗"
    print(f"{snr:>6}  {ber:>12.4e}  {s}")
